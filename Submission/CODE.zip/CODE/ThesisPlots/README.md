This directory contains the Matlab scripts that were used to produce the figures in the thesis.

Not all figures were generated using Matlab. 
Many were produced by using the Tikz library for Latex. The code for these figures is inside the respective .tex files.

